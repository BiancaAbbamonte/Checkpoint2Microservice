package br.com.fiap.challenge.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Dados {
    @Id
    private Long empresaId;
    private String sitesFavoritados;
    private String sitesSugeridos;
    private String nichos;
    private String noticiasImportantes;
    private String concorrencia;

    public Long getEmpresaId() {
        return empresaId;
    }

    public void setEmpresaId(Long empresaId) {
        this.empresaId = empresaId;
    }

    public String getSitesFavoritados() {
        return sitesFavoritados;
    }

    public void setSitesFavoritados(String sitesFavoritados) {
        this.sitesFavoritados = sitesFavoritados;
    }

    public String getSitesSugeridos() {
        return sitesSugeridos;
    }

    public void setSitesSugeridos(String sitesSugeridos) {
        this.sitesSugeridos = sitesSugeridos;
    }

    public String getNichos() {
        return nichos;
    }

    public void setNichos(String nichos) {
        this.nichos = nichos;
    }

    public String getNoticiasImportantes() {
        return noticiasImportantes;
    }

    public void setNoticiasImportantes(String noticiasImportantes) {
        this.noticiasImportantes = noticiasImportantes;
    }

    public String getConcorrencia() {
        return concorrencia;
    }

    public void setConcorrencia(String concorrencia) {
        this.concorrencia = concorrencia;
    }
}
